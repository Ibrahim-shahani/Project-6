# Project6-Excel-Paytm-Epurchase-data
Project6-Excel-Paytm E-purchase Data: Utilized Excel to analyze Paytm e-purchase data, extracting insights on customer behavior, popular products, and transaction trends. Generated reports to inform marketing strategies and optimize sales
